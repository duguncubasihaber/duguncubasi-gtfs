Düğüncübaşı-Lüleburgaz GTFS

Bu sürümde yalnızca SHAPE_OUTBOUND (shapes.txt) üzerinde, gönderilen uydu ekranlarında kırmızı güzergâhın yol ekseninden belirgin saptığı görülen iki bölüm için kademeli geometrik düzeltme yapılmıştır. Duraklar, stop_times.txt ve diğer GTFS dosyaları değiştirilmemiştir.

Önemli: Bu düzeltme ekran görüntülerine dayalı yaklaşık yol hizalamasıdır; resmi/ölçülmüş yol merkez çizgisi verisi değildir. Gerçek yol geometrisiyle doğrulanırsa shapes.txt yeniden hassaslaştırılmalıdır.

V3: SHAPE_OUTBOUND mevcut yol geometrisi korunarak belirtilen durak koordinatlarından kesin geçecek şekilde güncellendi; SHAPE_INBOUND değiştirilmedi.


UMAP ROTA GUNCELLEMESI
- SHAPE_OUTBOUND: uMap GeoJSON'daki 'Gidis' çizgisi kullanıldı.
- SHAPE_INBOUND: 'Donus' çizgisi kullanıldı; isimsiz 10 noktalı çizginin Terminal -> Stad Karşısı kısmı başa eklendi. Bu isimsiz çizginin kalan kısmı 'Donus' çizgisiyle çakıştığı için tekrar edilmedi.
- Rota geometrileri kullanıcının uMap üzerinde çizdiği hatlardan alınmıştır.

22:25 seferi: HAFTAICI TRIP_HI_14 ve PAZAR TRIP_PZ_8, SEYTAN_DURAGI durağında sonlandırıldı. Bu iki sefer için ayrı kısa shape oluşturuldu.


TIMETABLE/DIRECTION UPDATE
- User supplied timetable: left column = Düğüncübaşı departures; right column = Lüleburgaz departures.
- Weekday+Saturday return departures: 07:00, 08:00, 09:00, 10:00, 11:00, 12:00, 13:00, 14:00, 15:00, 16:00, 17:00, 18:00, 19:00.
- Sunday return departures: 07:00, 09:00, 11:00, 13:00, 15:00, 17:00, 19:00.
- Special night trip: 22:25 Düğüncübaşı -> Şeytan Durağı; 00:55 Şeytan Durağı -> Düğüncübaşı.
- Intermediate return stop times are estimated because the supplied image specifies origin departure times, not every stop's exact time.


Saat düzeltmesi: Kullanıcının verdiği uç nokta kalkış saatleri korunmuştur. Düğüncübaşı-Terminal tam seferleri 35 dakika yolculuk süresiyle düzenlenmiştir; dönüş tam seferleri de Terminal kalkışından Düğüncübaşı varışına 35 dakika olacak şekilde düzenlenmiştir. 22:25 özel seferi yalnızca Şeytan Durağına, 00:55 özel dönüşü Şeytan Durağından Düğüncübaşına gider. Ara durak saatleri bu 35 dakikalık süreye göre hesaplanmıştır ve gerçek ölçüm olarak değerlendirilmemelidir.